# chapter6
Code samples for Chapter 6 The IoT Hardware Package

**Source**: *This sample code is originated and forked from one the seed repositorires that Balena offers to start working with its platform, i.e.* https://github.com/balena-io-playground/sense-hat-base-application
