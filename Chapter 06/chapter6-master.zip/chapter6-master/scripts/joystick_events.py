#!/usr/bin/python3
from sense_hat import SenseHat
from signal import pause
from time import sleep

timeOfRainbow = 5
sleep(timeOfRainbow + 10) # Wait until rainbow is shown in the LED matrix for 5 seconds
print ("--- THIRD TEST: Move a dot on the LED matrix using the joystick")
print ("--- This is an event oriented program, so it's always listening to the joystick")

x = y = 4
hat = SenseHat()

def update_screen():
    hat.clear()
    hat.set_pixel(x, y, 255, 255, 255)

def clamp(value, min_value=0, max_value=7):
    return min(max_value, max(min_value, value))

def move_dot(event):
    global x, y
    if event.action in ('pressed', 'held'):
        x = clamp(x + {
            'left': -1,
            'right': 1,
            }.get(event.direction, 0))
        y = clamp(y + {
            'up': -1,
            'down': 1,
            }.get(event.direction, 0))

update_screen()
hat.stick.direction_up = move_dot
hat.stick.direction_down = move_dot
hat.stick.direction_left = move_dot
hat.stick.direction_right = move_dot
hat.stick.direction_any = update_screen
pause()
